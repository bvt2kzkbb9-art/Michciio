/**
 * ============================================================
 * WEEKEND WARRIOR SOCIAL — firebase-config-template.js
 * ============================================================
 * 
 * ⚠️ INSTRUKCJE:
 * 1. Skopiuj ten plik: firebase-config-template.js → firebase-config.js
 * 2. Uzupełnij wartości z Firebase Console
 * 3. Dodaj firebase-config.js do .gitignore (już dodane)
 * 4. NIGDY nie commituj tego pliku do Git!
 * 
 * Jak znaleźć wartości:
 * - Przejdź do: Firebase Console → Ustawienia projektu
 * - Kliknij: Aplikacje → Twoja aplikacja webowa
 * - Skopiuj firebaseConfig object
 * ============================================================
 */

// Zmienna globalna — będzie wczytana w firebase.js
window.FIREBASE_API_KEY = 'YOUR_API_KEY_HERE';
window.FIREBASE_AUTH_DOMAIN = 'YOUR_PROJECT_ID.firebaseapp.com';
window.FIREBASE_PROJECT_ID = 'YOUR_PROJECT_ID';
window.FIREBASE_STORAGE_BUCKET = 'YOUR_PROJECT_ID.appspot.com';
window.FIREBASE_MESSAGING_SENDER_ID = 'YOUR_MESSAGING_SENDER_ID';
window.FIREBASE_APP_ID = 'YOUR_APP_ID';

/**
 * PRZYKŁAD (z rzeczywistego projektu testowego — nie wdrażaj tego):
 * 
 * window.FIREBASE_API_KEY = 'AIzaSyA9I-uUmWLLjq8WNrAgnlmXQxiAgRR1U98';
 * window.FIREBASE_AUTH_DOMAIN = 'weekend-warrior-social-ed3d0.firebaseapp.com';
 * window.FIREBASE_PROJECT_ID = 'weekend-warrior-social-ed3d0';
 * window.FIREBASE_STORAGE_BUCKET = 'weekend-warrior-social-ed3d0.appspot.com';
 * window.FIREBASE_MESSAGING_SENDER_ID = '487311448505';
 * window.FIREBASE_APP_ID = '1:487311448505:web:ffbe035b92efa8fc193e68';
 */

console.log('[Firebase Config] Template loaded — uzupełnij wartości i zmień nazwę na firebase-config.js');
